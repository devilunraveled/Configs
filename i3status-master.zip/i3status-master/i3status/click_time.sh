#!/bin/sh

# show year calendar with week numbers
# and press any key to exit
cal -yw
read -n 1 -r -s
